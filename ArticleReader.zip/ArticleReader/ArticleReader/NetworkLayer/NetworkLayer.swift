//
//  NetworkLayer.swift
//  ArticleReader
//
//  Created by Prashanth on 30/03/24.
//

import Foundation

protocol NetworkLayerProtocol {
    func fetchData<Response: Decodable>(urlRequest: URLRequest, completion: @escaping (Result<Response, Error>) -> Void)
}

class NetworkLayer: NetworkLayerProtocol {
    
    let session: URLSession
    
    init(session: URLSession = .shared) {
        self.session = session
    }
    
    func fetchData<Response: Decodable>(urlRequest: URLRequest, completion: @escaping (Result<Response, Error>) -> Void) {
        session.dataTask(with: urlRequest) { [weak self] data, response, error in
            guard let self = self, let data = data, let httpResponse = response as? HTTPURLResponse,
                  200..<300 ~= httpResponse.statusCode, error == nil else {
                completion(.failure(error ?? URLError(.badServerResponse)))
                return
            }
            do {
                let model: Response = try self.parseResponse(data: data)
                completion(.success(model))
            } catch {
                completion(.failure(error))
            }
        }.resume()
    }
    
    func parseResponse<Response: Decodable>(data: Data) throws -> Response {
        return try JSONDecoder().decode(Response.self, from: data)
    }
}

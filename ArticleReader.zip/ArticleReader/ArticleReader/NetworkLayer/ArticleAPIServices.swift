//
//  ArticleAPIServices.swift
//  ArticleReader
//
//  Created by Prashanth on 30/03/24.
//

import Foundation

// MARK: - Article API Request

protocol ArticleAPIServiceProtocol {
    func fetchData(completion: @escaping (Result<ArticleResponseModel, Error>) -> Void)
}

class ArticleAPIServices: ArticleAPIServiceProtocol {
    let networkLayer: NetworkLayerProtocol
    
    init(networkLayer: NetworkLayerProtocol = NetworkLayer()) {
        self.networkLayer = networkLayer
    }
    
    var urlRequest: URLRequest {
        guard let url = URL(string: "https://api.nytimes.com/svc/search/v2/articlesearch.json?q=election&api-key=j5GCulxBywG3lX211ZAPkAB8O381S5SM") else {
            fatalError("Invalid URL")
        }
        return URLRequest(url: url)
    }
    
    func fetchData(completion: @escaping (Result<ArticleResponseModel, Error>) -> Void) {
        networkLayer.fetchData(urlRequest: urlRequest, completion: completion)
    }
}

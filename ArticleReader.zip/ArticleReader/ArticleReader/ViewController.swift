//
//  ViewController.swift
//  ArticleReader
//
//  Created by Prashanth on 30/03/24.
//

import UIKit

class ViewController: UIViewController {
    
    var viewModel: ArticleViewModel!
    var selectedIndexPath: IndexPath?
    
    @IBOutlet weak var articleDetailsTableView: UITableView!
    @IBOutlet weak var submitBtn: UIButton!
    @IBOutlet weak var toastLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        viewModel = ArticleViewModel()
        setupUI()
        fetchArticles()
    }
    
    func setupUI() {
        setCornerRadius(view: submitBtn)
        setCornerRadius(view: toastLbl)
        articleDetailsTableView.delegate = self
        articleDetailsTableView.dataSource = self
        articleDetailsTableView.allowsMultipleSelection = true
        let dataCellNib = UINib.init(nibName: "ArticleTableCell", bundle: nil)
        articleDetailsTableView.register(dataCellNib, forCellReuseIdentifier: "ArticleTableCell")
    }
    
    func setCornerRadius(view: UIView) {
        view.clipsToBounds = true
        view.layer.cornerRadius = 8
    }
    
    func fetchArticles() {
        viewModel.fetchArticles { [weak self] in
            self?.reloadTableView()
        }
    }
    
    func reloadTableView() {
        DispatchQueue.main.async { [weak self] in
            self?.articleDetailsTableView?.reloadData()
        }
    }
    
    @IBAction func submitMethod(_ sender: UIButton) {
        if articleDetailsTableView != nil, let selectedRows = articleDetailsTableView.indexPathsForSelectedRows {
            processSelectedRows(indexpaths: selectedRows)
        }
    }
    
    func processSelectedRows(indexpaths: [IndexPath]) {
        for indexpath in indexpaths {
            let title = viewModel.articles[indexpath.row].title
            print("Process row at: \(indexpath.row) with title is \(title ?? "")")
        }
        toastLbl.isHidden = false
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [weak self] in
            self?.toastLbl.isHidden = true
        }
    }
}

//MARK: - TableView Delegate Methods
extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.articles.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "ArticleTableCell") as? ArticleTableCell {
            let showDivider = indexPath.row == viewModel.articles.count - 1
            cell.configureCell(article: viewModel.articles[indexPath.row], showDivider: showDivider)
            cell.radioImageView.image = indexPath == selectedIndexPath ? UIImage(named: "checkbox_fill") : UIImage(named: "checkbox_empty")
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let cell = tableView.cellForRow(at: indexPath) as? ArticleTableCell {
            cell.setSelected(true, animated: true)
            cell.radioImageView.image = UIImage(named: "checkbox_fill")
        }
    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        if let cell = tableView.cellForRow(at: indexPath) as? ArticleTableCell {
            cell.setSelected(false, animated: true)
            cell.radioImageView.image = UIImage(named: "checkbox_empty")
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}



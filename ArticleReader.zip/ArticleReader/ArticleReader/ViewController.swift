//
//  ViewController.swift
//  ArticleReader
//
//  Created by Prashanth on 30/03/24.
//

import UIKit

class ViewController: UIViewController {
    
    var viewModel: ArticleViewModel!
    
    @IBOutlet weak var articleDetailsTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        viewModel = ArticleViewModel()
        setupUI()
        fetchArticles()
    }
    
    func setupUI() {
        articleDetailsTableView.delegate = self
        articleDetailsTableView.dataSource = self
        let dataCellNib = UINib.init(nibName: "ArticleTableCell", bundle: nil)
        articleDetailsTableView.register(dataCellNib, forCellReuseIdentifier: "ArticleTableCell")
    }
    
    func fetchArticles() {
        viewModel.fetchArticles { [weak self] in
            self?.reloadTableView()
        }
    }
    
    func reloadTableView() {
        DispatchQueue.main.async { [weak self] in
            self?.articleDetailsTableView?.reloadData()
        }
    }
}

//MARK: - TableView Delegate Methods
extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.articles.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "ArticleTableCell") as? ArticleTableCell {
            let showDivider = indexPath.row == viewModel.articles.count - 1
            cell.configureCell(article: viewModel.articles[indexPath.row], showDivider: showDivider)
            return cell
        }
        return UITableViewCell()
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
}



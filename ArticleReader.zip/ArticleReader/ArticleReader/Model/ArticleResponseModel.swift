//
//  ArticleResponseModel.swift
//  ArticleReader
//
//  Created by Prashanth on 30/03/24.
//

import Foundation

struct ArticleResponseModel: Decodable {
    let response: ResponseData
    
    struct ResponseData: Decodable {
        let docs: [ArticleData]
    }
    
    struct ArticleData: Decodable {
        let headline: Headline
        let pub_date: String
        let abstract: String
        let multimedia: [Multimedia]?
        
        struct Headline: Decodable {
            let main: String
        }
        
        struct Multimedia: Decodable {
            let url: String
        }
    }
}

//
//  ImageDownloader.swift
//  ArticleReader
//
//  Created by Prashanth on 30/03/24.
//

import UIKit

class ImageDownloader {
    
    private static var cache: [String: UIImage] = [:]
    
    static func fetchImage(from urlString: String, completion: @escaping (UIImage?) -> Void) {
        if let image = cache[urlString] {
            completion(image)
            return
        }
        guard let url = URL(string: urlString) else {
            completion(nil)
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil, let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                completion(nil)
                return
            }
            
            if let image = UIImage(data: data) {
                cache[urlString] = image
                completion(image)
            } else {
                completion(nil)
            }
        }.resume()
    }
}

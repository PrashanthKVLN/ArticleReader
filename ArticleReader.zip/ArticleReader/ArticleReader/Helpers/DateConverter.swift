//
//  DateConverter.swift
//  ArticleReader
//
//  Created by Prashanth on 30/03/24.
//

import Foundation

class DateConverter {
    static func convertStringToDate(_ dateString: String) -> Date {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
        if let date = formatter.date(from: dateString) {
            return date
        } else {
            return Date()
        }
    }
    
    static func convertDateToString(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd MMMM yyyy"
        return formatter.string(from: date)
    }
}

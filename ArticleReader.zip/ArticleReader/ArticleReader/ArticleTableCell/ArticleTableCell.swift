//
//  ArticleTableCell.swift
//  ArticleReader
//
//  Created by Prashanth on 30/03/24.
//

import UIKit

class ArticleTableCell: UITableViewCell {
    
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var dateLbl: UILabel!
    @IBOutlet weak var articleContent: UILabel!
    @IBOutlet weak var articleImage: UIImageView!
    @IBOutlet weak var divider: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.clipsToBounds = true
        self.layer.cornerRadius = 8
    }
    
    func configureCell(article: Article, showDivider: Bool) {
        title.text = article.title
        articleContent.text = article.articleDescription
        divider.isHidden = showDivider
        if let date = article.date {
            dateLbl.text = DateConverter.convertDateToString(date)
        }
        guard var imageUrl = article.imageUrl else { return }
        imageUrl = "https://www.nytimes.com/" + imageUrl
        ImageDownloader.fetchImage(from: imageUrl) { [weak self] image in
            DispatchQueue.main.async {
                self?.articleImage.image = image
            }
        }
    }
}

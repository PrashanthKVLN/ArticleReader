//
//  ArticlesViewModel.swift
//  ArticleReader
//
//  Created by Prashanth on 30/03/24.
//

import Foundation
import CoreData

class ArticleViewModel {
    
    var articles: [Article] = []
    var onErrorHandling: ((Error) -> Void)?
    let apiServices: ArticleAPIServiceProtocol
    
    init(apiServices: ArticleAPIServiceProtocol = ArticleAPIServices()) {
        self.apiServices = apiServices
    }
        
    func fetchArticles(completion: @escaping () -> Void) {
        apiServices.fetchData(completion: { [weak self] result in
            switch result {
            case .success(let response):
                let articleDataList = response.response.docs
                
                // Save articles to Core Data
                self?.saveArticlesToCoreData(articleDataList)
                
                // Fetch articles from Core Data
                self?.fetchArticlesFromCoreData {
                    completion()
                }
                
            case .failure(let error):
                self?.onErrorHandling?(error)
                // Fetch articles from Core Data
                self?.fetchArticlesFromCoreData {
                    completion()
                }
            }
        })
    }

    private func saveArticlesToCoreData(_ articleDataList: [ArticleResponseModel.ArticleData]) {
        let context = CoreDataManager.shared.persistentContainer.viewContext
        
        // Remove existing articles
        let fetchRequest: NSFetchRequest<Article> = Article.fetchRequest()
        if let existingArticles = try? context.fetch(fetchRequest) {
            for article in existingArticles {
                context.delete(article)
            }
        }
        
        // Create new article entities
        for articleData in articleDataList {
            let articleEntity = Article(context: context)
            articleEntity.title = articleData.headline.main
            articleEntity.articleDescription = articleData.abstract
            articleEntity.date = DateConverter.convertStringToDate(articleData.pub_date)
            articleEntity.imageUrl = articleData.multimedia?.first?.url ?? ""
        }
        
        // Save changes to Core Data
        CoreDataManager.shared.saveContext()
    }

    private func fetchArticlesFromCoreData(completion: @escaping () -> Void) {
        let context = CoreDataManager.shared.persistentContainer.viewContext
        let fetchRequest: NSFetchRequest<Article> = Article.fetchRequest()
        
        let sortDescriptor = NSSortDescriptor(key: "date", ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        do {
            let articles = try context.fetch(fetchRequest)
            self.articles = articles
            completion()
        } catch {
            self.onErrorHandling?(error)
        }
    }
}
